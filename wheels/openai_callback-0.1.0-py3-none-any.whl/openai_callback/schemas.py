"""Modèles de données pour le tracking de tokens OpenAI.

`RequestLog` — log d'une requête HTTP individuelle.
`Usage` — agrégation de tous les logs d'une session de tracking.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field

# ── Détection du type d'endpoint ─────────────────────────────────────────────

_ENDPOINT_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("chat_completions", re.compile(r"/chat/completions")),
    ("responses", re.compile(r"/responses")),
    ("embeddings", re.compile(r"/embeddings")),
    ("images", re.compile(r"/images/generations")),
    ("audio_transcription", re.compile(r"/audio/transcriptions")),
    ("completions", re.compile(r"/completions")),  # legacy — doit être après chat
]


def _detect_endpoint(url: str) -> str:
    for name, pattern in _ENDPOINT_PATTERNS:
        if pattern.search(url):
            return name
    return "unknown"


# ── Extraction de l'usage depuis un body JSON ───────────────────────────────


def _safe_get(d: dict, *keys: str, default: int = 0) -> int:
    """Navigue dans un dict imbriqué en toute sécurité."""
    current: Any = d
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key)
        if current is None:
            return default
    return int(current) if current is not None else default


class RequestLog(BaseModel):
    """Log d'une requête HTTP interceptée vers l'API OpenAI."""

    # Métadonnées HTTP
    url: str
    method: str = "POST"
    status_code: int = 200
    latency_ms: float = 0.0
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    streamed: bool = False

    # Modèle
    model: str | None = None
    endpoint_type: str = "unknown"

    # Tokens normalisés (prompt = input, completion = output)
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    # Détails prompt / input
    cached_tokens: int = 0
    audio_input_tokens: int = 0
    image_input_tokens: int = 0
    text_input_tokens: int = 0

    # Détails completion / output
    reasoning_tokens: int = 0
    audio_output_tokens: int = 0
    accepted_prediction_tokens: int = 0
    rejected_prediction_tokens: int = 0
    image_output_tokens: int = 0
    text_output_tokens: int = 0

    # Coût
    cost_usd: float | None = None

    @classmethod
    def from_response(
        cls,
        *,
        url: str,
        method: str,
        status_code: int,
        latency_ms: float,
        body: dict,
        request_body: dict | None = None,
        streamed: bool = False,
    ) -> RequestLog:
        """Construit un `RequestLog` à partir du JSON de réponse.

        Gère les deux conventions de nommage (Chat Completions vs Responses API)
        et la typo ``input_token_details`` (singulier) du endpoint audio transcription.
        """
        from openai_callback.pricing import get_cost

        endpoint_type = _detect_endpoint(url)
        usage = body.get("usage", {}) or {}

        # Modèle : priorité au request body (plus fiable pour les alias)
        model = None
        if request_body and isinstance(request_body, dict):
            model = request_body.get("model")
        if not model:
            model = body.get("model")

        # ── Tokens principaux ────────────────────────────────────────────
        # Chat Completions / Legacy : prompt_tokens / completion_tokens
        # Responses / Images / Audio : input_tokens / output_tokens
        prompt_tokens = (
            usage.get("prompt_tokens", 0) or usage.get("input_tokens", 0) or 0
        )
        completion_tokens = (
            usage.get("completion_tokens", 0) or usage.get("output_tokens", 0) or 0
        )
        total_tokens = usage.get("total_tokens", 0) or 0

        # ── Détails input / prompt ───────────────────────────────────────
        # Trois clés possibles : prompt_tokens_details, input_tokens_details, input_token_details (singular!)
        input_details = (
            usage.get("prompt_tokens_details")
            or usage.get("input_tokens_details")
            or usage.get("input_token_details")  # audio transcription typo
            or {}
        )
        cached_tokens = _safe_get(input_details, "cached_tokens")
        audio_input_tokens = _safe_get(input_details, "audio_tokens")
        image_input_tokens = _safe_get(input_details, "image_tokens")
        text_input_tokens = _safe_get(input_details, "text_tokens")

        # ── Détails output / completion ──────────────────────────────────
        output_details = (
            usage.get("completion_tokens_details")
            or usage.get("output_tokens_details")
            or {}
        )
        reasoning_tokens = _safe_get(output_details, "reasoning_tokens")
        audio_output_tokens = _safe_get(output_details, "audio_tokens")
        accepted_prediction_tokens = _safe_get(
            output_details, "accepted_prediction_tokens"
        )
        rejected_prediction_tokens = _safe_get(
            output_details, "rejected_prediction_tokens"
        )
        image_output_tokens = _safe_get(output_details, "image_tokens")
        text_output_tokens = _safe_get(output_details, "text_tokens")

        # ── Coût ─────────────────────────────────────────────────────────
        cost_usd = None
        if model:
            cost_usd = get_cost(model, prompt_tokens, completion_tokens, cached_tokens)

        return cls(
            url=url,
            method=method,
            status_code=status_code,
            latency_ms=latency_ms,
            streamed=streamed,
            model=model,
            endpoint_type=endpoint_type,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            cached_tokens=cached_tokens,
            audio_input_tokens=audio_input_tokens,
            image_input_tokens=image_input_tokens,
            text_input_tokens=text_input_tokens,
            reasoning_tokens=reasoning_tokens,
            audio_output_tokens=audio_output_tokens,
            accepted_prediction_tokens=accepted_prediction_tokens,
            rejected_prediction_tokens=rejected_prediction_tokens,
            image_output_tokens=image_output_tokens,
            text_output_tokens=text_output_tokens,
            cost_usd=cost_usd,
        )


# ── Champs accumulés ─────────────────────────────────────────────────────────

_ACCUMULATE_FIELDS: tuple[str, ...] = (
    "prompt_tokens",
    "completion_tokens",
    "total_tokens",
    "cached_tokens",
    "audio_input_tokens",
    "image_input_tokens",
    "text_input_tokens",
    "reasoning_tokens",
    "audio_output_tokens",
    "accepted_prediction_tokens",
    "rejected_prediction_tokens",
    "image_output_tokens",
    "text_output_tokens",
)


class Usage(BaseModel):
    """Agrégation de l'usage de tokens sur plusieurs requêtes."""

    # Tokens cumulés
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    # Détails cumulés
    cached_tokens: int = 0
    audio_input_tokens: int = 0
    image_input_tokens: int = 0
    text_input_tokens: int = 0
    reasoning_tokens: int = 0
    audio_output_tokens: int = 0
    accepted_prediction_tokens: int = 0
    rejected_prediction_tokens: int = 0
    image_output_tokens: int = 0
    text_output_tokens: int = 0

    # Métriques
    requests: int = 0
    total_cost: float = 0.0
    total_latency_ms: float = 0.0

    # Détail
    logs: list[RequestLog] = Field(default_factory=list)
    models: dict[str, int] = Field(default_factory=dict)

    def _record(self, log: RequestLog) -> None:
        """Enregistre un `RequestLog` et met à jour les totaux."""
        self.logs.append(log)
        self.requests += 1
        self.total_latency_ms += log.latency_ms

        for field in _ACCUMULATE_FIELDS:
            current = getattr(self, field)
            setattr(self, field, current + getattr(log, field))

        if log.cost_usd is not None:
            self.total_cost += log.cost_usd

        if log.model:
            self.models[log.model] = self.models.get(log.model, 0) + 1

    def __add__(self, other: Usage) -> Usage:
        if not isinstance(other, Usage):
            return NotImplemented
        result = Usage()
        for field in _ACCUMULATE_FIELDS:
            setattr(result, field, getattr(self, field) + getattr(other, field))
        result.requests = self.requests + other.requests
        result.total_cost = self.total_cost + other.total_cost
        result.total_latency_ms = self.total_latency_ms + other.total_latency_ms
        result.logs = [*self.logs, *other.logs]
        merged_models: dict[str, int] = dict(self.models)
        for model, count in other.models.items():
            merged_models[model] = merged_models.get(model, 0) + count
        result.models = merged_models
        return result

    def __iadd__(self, other: Usage) -> Usage:
        if not isinstance(other, Usage):
            return NotImplemented
        for field in _ACCUMULATE_FIELDS:
            setattr(self, field, getattr(self, field) + getattr(other, field))
        self.requests += other.requests
        self.total_cost += other.total_cost
        self.total_latency_ms += other.total_latency_ms
        self.logs.extend(other.logs)
        for model, count in other.models.items():
            self.models[model] = self.models.get(model, 0) + count
        return self

    def to_dict(self) -> dict[str, Any]:
        """Sérialise l'usage sous forme de dict (sans les logs détaillés)."""
        return {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "cached_tokens": self.cached_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "audio_input_tokens": self.audio_input_tokens,
            "audio_output_tokens": self.audio_output_tokens,
            "image_input_tokens": self.image_input_tokens,
            "image_output_tokens": self.image_output_tokens,
            "text_input_tokens": self.text_input_tokens,
            "text_output_tokens": self.text_output_tokens,
            "accepted_prediction_tokens": self.accepted_prediction_tokens,
            "rejected_prediction_tokens": self.rejected_prediction_tokens,
            "requests": self.requests,
            "total_cost": self.total_cost,
            "total_latency_ms": self.total_latency_ms,
            "models": dict(self.models),
        }

    def __repr__(self) -> str:
        lines = [
            f"Tokens Used: {self.total_tokens}",
            f"    Prompt Tokens: {self.prompt_tokens}",
        ]
        if self.cached_tokens:
            lines.append(f"        Cached Tokens: {self.cached_tokens}")
        if self.audio_input_tokens:
            lines.append(f"        Audio Input Tokens: {self.audio_input_tokens}")
        if self.image_input_tokens:
            lines.append(f"        Image Input Tokens: {self.image_input_tokens}")
        lines.append(f"    Completion Tokens: {self.completion_tokens}")
        if self.reasoning_tokens:
            lines.append(f"        Reasoning Tokens: {self.reasoning_tokens}")
        if self.audio_output_tokens:
            lines.append(f"        Audio Output Tokens: {self.audio_output_tokens}")
        if self.accepted_prediction_tokens:
            lines.append(
                f"        Accepted Prediction Tokens: {self.accepted_prediction_tokens}"
            )
        if self.rejected_prediction_tokens:
            lines.append(
                f"        Rejected Prediction Tokens: {self.rejected_prediction_tokens}"
            )
        if self.image_output_tokens:
            lines.append(f"        Image Output Tokens: {self.image_output_tokens}")
        lines.extend(
            [
                f"Successful Requests: {self.requests}",
                f"Total Cost (USD): ${self.total_cost:.6f}",
                f"Total Latency: {self.total_latency_ms:.0f}ms",
            ]
        )
        if self.models:
            lines.append(f"Models: {self.models}")
        return "\n".join(lines)

    def __str__(self) -> str:
        return self.__repr__()
