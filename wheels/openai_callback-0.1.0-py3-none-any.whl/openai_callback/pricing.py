"""Table de prix par modèle OpenAI et calcul de coût.

Prix en USD par 1 million de tokens (standard tier, février 2026).
"""

from __future__ import annotations

from pydantic import BaseModel


class Pricing(BaseModel):
    """Prix d'un modèle en USD par 1M tokens."""

    input_price: float
    output_price: float
    cached_input_price: float = 0.0

    def compute_cost(
        self,
        prompt_tokens: int,
        completion_tokens: int,
        cached_tokens: int = 0,
    ) -> float:
        """Calcule le coût en USD."""
        uncached_input = prompt_tokens - cached_tokens
        return (
            uncached_input * self.input_price
            + cached_tokens * self.cached_input_price
            + completion_tokens * self.output_price
        ) / 1_000_000


# ── Table de prix ────────────────────────────────────────────────────────────
# Triée du plus spécifique au plus général pour le prefix-matching.

PRICING_TABLE: dict[str, Pricing] = {
    # GPT-5 family
    "gpt-5.2-pro": Pricing(
        input_price=21.0,
        output_price=168.0,
        cached_input_price=21.0,  # no cache discount
    ),
    "gpt-5.2": Pricing(input_price=1.75, output_price=14.0, cached_input_price=0.175),
    "gpt-5.1": Pricing(input_price=1.25, output_price=10.0, cached_input_price=0.125),
    "gpt-5-pro": Pricing(
        input_price=15.0,
        output_price=120.0,
        cached_input_price=15.0,  # no cache discount
    ),
    "gpt-5-mini": Pricing(input_price=0.25, output_price=2.0, cached_input_price=0.025),
    "gpt-5-nano": Pricing(
        input_price=0.05, output_price=0.40, cached_input_price=0.005
    ),
    "gpt-5": Pricing(input_price=1.25, output_price=10.0, cached_input_price=0.125),
    # GPT-4.1 family
    "gpt-4.1-mini": Pricing(
        input_price=0.40, output_price=1.60, cached_input_price=0.10
    ),
    "gpt-4.1-nano": Pricing(
        input_price=0.10, output_price=0.40, cached_input_price=0.025
    ),
    "gpt-4.1": Pricing(input_price=2.00, output_price=8.00, cached_input_price=0.50),
    # GPT-4o family
    "gpt-4o-mini": Pricing(
        input_price=0.15, output_price=0.60, cached_input_price=0.075
    ),
    "gpt-4o": Pricing(input_price=2.50, output_price=10.0, cached_input_price=1.25),
    # o-series reasoning
    "o3-pro": Pricing(
        input_price=20.0,
        output_price=80.0,
        cached_input_price=20.0,  # no cache discount
    ),
    "o3-mini": Pricing(input_price=1.10, output_price=4.40, cached_input_price=0.55),
    "o3": Pricing(input_price=2.00, output_price=8.00, cached_input_price=0.50),
    "o4-mini": Pricing(input_price=1.10, output_price=4.40, cached_input_price=0.275),
    "o1-mini": Pricing(input_price=1.10, output_price=4.40, cached_input_price=0.55),
    "o1": Pricing(input_price=15.0, output_price=60.0, cached_input_price=7.50),
    # Embeddings
    "text-embedding-3-small": Pricing(input_price=0.02, output_price=0.0),
    "text-embedding-3-large": Pricing(input_price=0.13, output_price=0.0),
    "text-embedding-ada-002": Pricing(input_price=0.10, output_price=0.0),
}

# Registre utilisateur (vérifié avant PRICING_TABLE)
_custom_models: dict[str, Pricing] = {}


def register_model(pattern: str, pricing: Pricing) -> None:
    """Enregistre un modèle custom dans la table de prix.

    Args:
        pattern: Préfixe du nom de modèle (ex: ``"ft:gpt-4o-mini"``).
        pricing: Tarification associée.
    """
    _custom_models[pattern] = pricing


def _match_model(model: str) -> Pricing | None:
    """Trouve le pricing d'un modèle par prefix-matching."""
    # Cherche d'abord dans les modèles custom
    for pattern, pricing in _custom_models.items():
        if model.startswith(pattern):
            return pricing
    # Puis dans la table standard
    for pattern, pricing in PRICING_TABLE.items():
        if model.startswith(pattern):
            return pricing
    return None


def get_cost(
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    cached_tokens: int = 0,
) -> float | None:
    """Calcule le coût d'une requête en USD, ou ``None`` si le modèle est inconnu.

    Args:
        model: Nom du modèle (ex: ``"gpt-4o-mini-2024-07-18"``).
        prompt_tokens: Nombre de tokens d'entrée.
        completion_tokens: Nombre de tokens de sortie.
        cached_tokens: Nombre de tokens d'entrée servis depuis le cache.

    Returns:
        Coût en USD, ou ``None`` si le modèle n'est pas dans la table de prix.
    """
    pricing = _match_model(model)
    if pricing is None:
        return None
    return pricing.compute_cost(prompt_tokens, completion_tokens, cached_tokens)
