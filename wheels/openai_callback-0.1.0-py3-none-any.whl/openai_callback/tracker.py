"""Context manager principal pour le tracking de tokens OpenAI.

Usage basique ::

    from openai_callback import track_usage

    with track_usage() as usage:
        # N'importe quel code qui appelle l'API OpenAI
        client.chat.completions.create(...)

    print(usage)  # Affiche les tokens consommés

Fonctionne aussi en async ::

    async with track_usage() as usage:
        await client.chat.completions.create(...)
"""

from __future__ import annotations

from types import TracebackType

from openai_callback._state import pop_tracker, push_tracker
from openai_callback.interceptors import install
from openai_callback.schemas import Usage


class UsageTracker:
    """Context manager bi-mode (sync + async) pour tracker les tokens OpenAI.

    Implémente à la fois ``__enter__``/``__exit__`` et
    ``__aenter__``/``__aexit__`` pour une utilisation transparente
    en sync ou async.
    """

    def __init__(self) -> None:
        self._usage = Usage()

    @property
    def usage(self) -> Usage:
        return self._usage

    def _setup(self) -> Usage:
        install()
        push_tracker(self._usage)
        return self._usage

    def _teardown(self) -> None:
        pop_tracker()

    # ── Sync context manager ─────────────────────────────────────────────

    def __enter__(self) -> Usage:
        return self._setup()

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self._teardown()

    # ── Async context manager ────────────────────────────────────────────

    async def __aenter__(self) -> Usage:
        return self._setup()

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self._teardown()


def track_usage() -> UsageTracker:
    """Crée un context manager pour tracker l'usage de tokens OpenAI.

    Returns:
        Un ``UsageTracker`` utilisable en ``with`` ou ``async with``.

    Example::

        with track_usage() as usage:
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello!"}],
            )

        print(f"Tokens: {usage.total_tokens}, Cost: ${usage.total_cost:.6f}")
    """
    return UsageTracker()
