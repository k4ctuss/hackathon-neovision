"""openai-callback — Generic HTTP-level OpenAI token usage tracker.

Intercepte transparemment les requêtes HTTP vers l'API OpenAI (et Azure)
pour comptabiliser les tokens consommés. Fonctionne avec n'importe quelle
lib Python qui appelle l'API OpenAI : ``openai``, ``langchain-openai``,
``llama-index``, ``crewai``, scripts custom, etc.

Usage basique ::

    from openai_callback import track_usage

    with track_usage() as usage:
        client.chat.completions.create(...)

    print(usage)
"""

from openai_callback.pricing import Pricing, get_cost, register_model
from openai_callback.schemas import RequestLog, Usage
from openai_callback.tracker import track_usage

__all__ = [
    "track_usage",
    "Usage",
    "RequestLog",
    "Pricing",
    "get_cost",
    "register_model",
]
