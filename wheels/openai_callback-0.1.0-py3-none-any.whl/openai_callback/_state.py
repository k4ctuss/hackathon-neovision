"""État global thread-safe pour les trackers actifs.

Utilise `contextvars.ContextVar` pour stocker la pile des `Usage` actifs
dans le contexte courant (thread-safe et asyncio-safe nativement).
"""

from __future__ import annotations

from contextvars import ContextVar
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from openai_callback.schemas import Usage

_active_trackers: ContextVar[list[Usage]] = ContextVar(
    "_active_trackers",
    default=[],
)


def push_tracker(usage: Usage) -> None:
    """Empile un tracker dans le contexte courant."""
    stack = _active_trackers.get()
    # On copie la liste pour éviter de muter la default partagée
    new_stack = [*stack, usage]
    _active_trackers.set(new_stack)


def pop_tracker() -> Usage:
    """Dépile le dernier tracker du contexte courant."""
    stack = _active_trackers.get()
    if not stack:
        raise RuntimeError("pop_tracker() appelé sans tracker actif")
    new_stack = stack[:-1]
    popped = stack[-1]
    _active_trackers.set(new_stack)
    return popped


def get_active_trackers() -> list[Usage]:
    """Retourne la liste des trackers actifs (peut être vide)."""
    return _active_trackers.get()
