"""Wrapper SSE pour intercepter les tokens dans les réponses streaming.

Wrape le stream httpx pour parser les Server-Sent Events (SSE) et extraire
l'objet ``usage`` du dernier chunk, sans perturber le flux de bytes original.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Iterator

logger = logging.getLogger("openai_callback")

# Import des classes de base httpx pour l'héritage (nécessaire pour isinstance checks).
# On importe dynamiquement pour ne pas forcer httpx comme dépendance.
# httpx ≤0.27 : classes dans httpx._transports.base
# httpx ≥0.28 : classes déplacées dans httpx._models (ré-exportées depuis httpx)
_SyncByteStream: type = object  # type: ignore[assignment]
_AsyncByteStream: type = object  # type: ignore[assignment]
try:
    from httpx import (
        AsyncByteStream as _AsyncByteStream,  # type: ignore[assignment, no-redef]
    )
    from httpx import (
        SyncByteStream as _SyncByteStream,  # type: ignore[assignment, no-redef]
    )
except ImportError:
    try:
        from httpx._transports.base import (
            AsyncByteStream as _AsyncByteStream,  # type: ignore[assignment, no-redef]
        )
        from httpx._transports.base import (
            SyncByteStream as _SyncByteStream,  # type: ignore[assignment, no-redef]
        )
    except ImportError:
        pass  # Falls back to object


def _extract_usage_from_sse_lines(lines: list[str]) -> tuple[dict | None, str | None]:
    """Parse les lignes SSE accumulées et extrait l'usage + le modèle.

    Deux modes d'extraction :
    - **Chat Completions** : le dernier ``data: {...}`` avant ``data: [DONE]``
      contient ``"usage": {...}`` (si ``stream_options.include_usage=true``).
    - **Responses API** : un event ``response.completed`` (ou ``response.done``)
      contient l'objet complet avec ``"usage": {...}``.

    Returns:
        Tuple (usage_dict, model) — chacun peut être ``None`` si non trouvé.
    """
    usage: dict | None = None
    model: str | None = None
    current_event_type: str | None = None

    for line in lines:
        stripped = line.strip()

        # SSE event type line
        if stripped.startswith("event:"):
            current_event_type = stripped[len("event:") :].strip()
            continue

        if not stripped.startswith("data:"):
            continue

        data_str = stripped[len("data:") :].strip()
        if data_str == "[DONE]":
            continue

        try:
            data = json.loads(data_str)
        except (json.JSONDecodeError, ValueError):
            continue

        if not isinstance(data, dict):
            continue

        # Extraire le modèle du premier chunk
        if model is None and "model" in data:
            model = data["model"]

        # Chat Completions : l'usage est dans le dernier chunk
        if "usage" in data and data["usage"]:
            usage = data["usage"]

        # Responses API : event response.completed contient l'objet complet
        if current_event_type in ("response.completed", "response.done"):
            if "response" in data and isinstance(data["response"], dict):
                resp = data["response"]
                if "usage" in resp and resp["usage"]:
                    usage = resp["usage"]
                if model is None and "model" in resp:
                    model = resp["model"]
            elif "usage" in data and data["usage"]:
                usage = data["usage"]

        # Reset event type after data line
        current_event_type = None

    return usage, model


class SyncSSEStreamWrapper(_SyncByteStream):  # type: ignore[misc]
    """Wrapper synchrone pour le stream de bytes httpx.

    Hérite de ``httpx.SyncByteStream`` pour passer les checks ``isinstance``
    internes de httpx (utilisés par ``Response.iter_raw()``, ``.read()``, etc.).
    """

    def __init__(self, original_stream: Any, *, callback: Any) -> None:
        self._original = original_stream
        self._callback = callback  # Callable[[dict, str | None], None]
        self._buffer = b""
        self._lines: list[str] = []
        self._closed = False

    def __iter__(self) -> Iterator[bytes]:
        try:
            for chunk in self._original:
                self._accumulate(chunk)
                yield chunk
        finally:
            self._finalize()

    def _accumulate(self, chunk: bytes) -> None:
        """Bufferise les bytes et extrait les lignes SSE complètes."""
        self._buffer += chunk
        while b"\n" in self._buffer:
            line_bytes, self._buffer = self._buffer.split(b"\n", 1)
            self._lines.append(line_bytes.decode("utf-8", errors="replace"))

    def _finalize(self) -> None:
        """Parse les lignes SSE et appelle le callback avec l'usage extrait."""
        if self._closed:
            return
        self._closed = True
        # Flush remaining buffer
        if self._buffer:
            self._lines.append(self._buffer.decode("utf-8", errors="replace"))
        try:
            usage, model = _extract_usage_from_sse_lines(self._lines)
            if usage:
                self._callback(usage, model)
        except Exception:
            logger.debug("SSE parsing failed", exc_info=True)

    def close(self) -> None:
        self._finalize()
        if hasattr(self._original, "close"):
            self._original.close()


class AsyncSSEStreamWrapper(_AsyncByteStream):  # type: ignore[misc]
    """Wrapper asynchrone pour le stream de bytes httpx.

    Hérite de ``httpx.AsyncByteStream`` pour passer les checks ``isinstance``.
    """

    def __init__(self, original_stream: Any, *, callback: Any) -> None:
        self._original = original_stream
        self._callback = callback
        self._buffer = b""
        self._lines: list[str] = []
        self._closed = False

    async def __aiter__(self) -> AsyncIterator[bytes]:
        try:
            async for chunk in self._original:
                self._accumulate(chunk)
                yield chunk
        finally:
            self._finalize()

    def _accumulate(self, chunk: bytes) -> None:
        self._buffer += chunk
        while b"\n" in self._buffer:
            line_bytes, self._buffer = self._buffer.split(b"\n", 1)
            self._lines.append(line_bytes.decode("utf-8", errors="replace"))

    def _finalize(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._buffer:
            self._lines.append(self._buffer.decode("utf-8", errors="replace"))
        try:
            usage, model = _extract_usage_from_sse_lines(self._lines)
            if usage:
                self._callback(usage, model)
        except Exception:
            logger.debug("Async SSE parsing failed", exc_info=True)

    async def aclose(self) -> None:
        self._finalize()
        if hasattr(self._original, "aclose"):
            await self._original.aclose()
