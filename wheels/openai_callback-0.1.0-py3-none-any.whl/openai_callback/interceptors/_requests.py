"""Monkeypatch de ``requests.sessions.Session.request``.

Intercepte les requêtes vers l'API OpenAI pour logger l'usage de tokens.
Activé uniquement si ``requests`` est importé dans le processus.

Note : le SDK OpenAI moderne (>=1.0) utilise httpx, pas requests.
Ce patch est un filet de sécurité pour les scripts qui utiliseraient
requests directement ou via des wrappers legacy.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

logger = logging.getLogger("openai_callback")

_original_request: Any = None
_installed = False

_OPENAI_HOSTS = ("api.openai.com", "openai.azure.com")


def _is_openai_url(url: str) -> bool:
    return any(h in url for h in _OPENAI_HOSTS)


def _patched_request(self: Any, method: str, url: str, **kwargs: Any) -> Any:
    from openai_callback._state import get_active_trackers

    if not get_active_trackers():
        return _original_request(self, method, url, **kwargs)

    if not _is_openai_url(url):
        return _original_request(self, method, url, **kwargs)

    # Tenter d'extraire le body de la requête
    request_body: dict | None = None
    json_kwarg = kwargs.get("json")
    if isinstance(json_kwarg, dict):
        request_body = json_kwarg
    elif "data" in kwargs:
        try:
            data = kwargs["data"]
            if isinstance(data, (str, bytes)):
                request_body = json.loads(data)
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError):
            pass

    t0 = time.perf_counter()

    try:
        response = _original_request(self, method, url, **kwargs)
    except Exception:
        raise

    try:
        latency_ms = (time.perf_counter() - t0) * 1000
        body = response.json()
        if isinstance(body, dict) and "usage" in body:
            from openai_callback.schemas import RequestLog

            trackers = get_active_trackers()
            log = RequestLog.from_response(
                url=url,
                method=method.upper(),
                status_code=response.status_code,
                latency_ms=latency_ms,
                body=body,
                request_body=request_body,
                streamed=False,
            )
            for tracker in trackers:
                tracker._record(log)
    except Exception:
        logger.debug("requests interceptor error", exc_info=True)

    return response


def install() -> None:
    """Applique le monkeypatch requests. Idempotent."""
    global _original_request, _installed

    if _installed:
        return

    try:
        import requests.sessions
    except ImportError:
        logger.debug("requests not installed, skipping requests interceptor")
        return

    _original_request = requests.sessions.Session.request
    requests.sessions.Session.request = _patched_request  # type: ignore[assignment]

    _installed = True
    logger.debug("requests interceptor installed")


def uninstall() -> None:
    """Restaure la méthode requests originale."""
    global _original_request, _installed

    if not _installed:
        return

    try:
        import requests.sessions
    except ImportError:
        return

    if _original_request is not None:
        requests.sessions.Session.request = _original_request  # type: ignore[assignment]

    _original_request = None
    _installed = False
    logger.debug("requests interceptor uninstalled")


def is_installed() -> bool:
    return _installed
