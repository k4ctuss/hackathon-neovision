"""Monkeypatch de ``httpx.Client.send`` et ``httpx.AsyncClient.send``.

Intercepte les requêtes vers l'API OpenAI (et Azure OpenAI) pour logger
l'usage de tokens. Le patch est transparent : si aucun tracker n'est actif,
l'overhead est quasi nul (un simple ``ContextVar.get()``).
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

logger = logging.getLogger("openai_callback")

# Références vers les méthodes originales (set par install/uninstall)
_original_sync_send: Any = None
_original_async_send: Any = None
_installed = False


# ── URL matching ─────────────────────────────────────────────────────────────

_OPENAI_HOSTS = ("api.openai.com", "openai.azure.com")


def _is_openai_url(url: Any) -> bool:
    """Vérifie si l'URL cible l'API OpenAI ou Azure OpenAI."""
    host = str(getattr(url, "host", url))
    return any(h in host for h in _OPENAI_HOSTS)


# ── Parsing helpers ──────────────────────────────────────────────────────────


def _try_parse_json(content: bytes) -> dict | None:
    try:
        data = json.loads(content)
        return data if isinstance(data, dict) else None
    except (json.JSONDecodeError, ValueError, UnicodeDecodeError):
        return None


def _extract_request_model(request: Any) -> dict | None:
    """Tente de parser le body de la requête pour en extraire le JSON."""
    try:
        content = request.content
        if content:
            return _try_parse_json(content)
    except Exception:
        pass
    return None


# ── Record helpers ───────────────────────────────────────────────────────────


def _record_log(
    url: str,
    method: str,
    status_code: int,
    latency_ms: float,
    body: dict,
    request_body: dict | None,
    streamed: bool,
) -> None:
    """Construit un RequestLog et l'enregistre dans tous les trackers actifs."""
    from openai_callback._state import get_active_trackers
    from openai_callback.schemas import RequestLog

    trackers = get_active_trackers()
    if not trackers:
        return

    try:
        log = RequestLog.from_response(
            url=url,
            method=method,
            status_code=status_code,
            latency_ms=latency_ms,
            body=body,
            request_body=request_body,
            streamed=streamed,
        )
        for tracker in trackers:
            tracker._record(log)
    except Exception:
        logger.debug("Failed to record request log", exc_info=True)


def _make_stream_callback(
    url: str,
    method: str,
    status_code: int,
    t0: float,
    request_body: dict | None,
) -> Any:
    """Crée un callback pour le wrapper SSE streaming."""

    def callback(usage: dict, model: str | None) -> None:
        latency_ms = (time.perf_counter() - t0) * 1000
        body: dict[str, Any] = {"usage": usage}
        if model:
            body["model"] = model
        _record_log(
            url, method, status_code, latency_ms, body, request_body, streamed=True
        )

    return callback


# ── Patched send (sync) ─────────────────────────────────────────────────────


def _patched_sync_send(self: Any, request: Any, **kwargs: Any) -> Any:
    from openai_callback._state import get_active_trackers

    # Fast path : pas de tracker actif → appel original direct
    if not get_active_trackers():
        return _original_sync_send(self, request, **kwargs)

    # Pas une URL OpenAI → pass-through
    if not _is_openai_url(request.url):
        return _original_sync_send(self, request, **kwargs)

    request_body = _extract_request_model(request)
    stream = kwargs.get("stream", False)
    t0 = time.perf_counter()

    try:
        response = _original_sync_send(self, request, **kwargs)
    except Exception:
        raise

    url = str(request.url)
    method = request.method

    try:
        if stream and 200 <= response.status_code < 300:
            # Streaming : wrapper le stream SSE (seulement si succès)
            from openai_callback.interceptors._stream import SyncSSEStreamWrapper

            callback = _make_stream_callback(
                url, method, response.status_code, t0, request_body
            )
            response.stream = SyncSSEStreamWrapper(response.stream, callback=callback)
        elif not stream:
            # Non-streaming : lire et parser le body
            latency_ms = (time.perf_counter() - t0) * 1000
            # Force la lecture du body si nécessaire
            if not hasattr(response, "_content") or response._content is None:
                response.read()
            body = _try_parse_json(response.content)
            if body and "usage" in body:
                _record_log(
                    url,
                    method,
                    response.status_code,
                    latency_ms,
                    body,
                    request_body,
                    streamed=False,
                )
    except Exception:
        logger.debug("httpx sync interceptor error", exc_info=True)

    return response


# ── Patched send (async) ────────────────────────────────────────────────────


async def _patched_async_send(self: Any, request: Any, **kwargs: Any) -> Any:
    from openai_callback._state import get_active_trackers

    if not get_active_trackers():
        return await _original_async_send(self, request, **kwargs)

    if not _is_openai_url(request.url):
        return await _original_async_send(self, request, **kwargs)

    request_body = _extract_request_model(request)
    stream = kwargs.get("stream", False)
    t0 = time.perf_counter()

    try:
        response = await _original_async_send(self, request, **kwargs)
    except Exception:
        raise

    url = str(request.url)
    method = request.method

    try:
        if stream and 200 <= response.status_code < 300:
            from openai_callback.interceptors._stream import AsyncSSEStreamWrapper

            callback = _make_stream_callback(
                url, method, response.status_code, t0, request_body
            )
            response.stream = AsyncSSEStreamWrapper(response.stream, callback=callback)
        elif not stream:
            latency_ms = (time.perf_counter() - t0) * 1000
            if not hasattr(response, "_content") or response._content is None:
                await response.aread()
            body = _try_parse_json(response.content)
            if body and "usage" in body:
                _record_log(
                    url,
                    method,
                    response.status_code,
                    latency_ms,
                    body,
                    request_body,
                    streamed=False,
                )
    except Exception:
        logger.debug("httpx async interceptor error", exc_info=True)

    return response


# ── Install / Uninstall ──────────────────────────────────────────────────────


def install() -> None:
    """Applique les monkeypatches httpx. Idempotent."""
    global _original_sync_send, _original_async_send, _installed

    if _installed:
        return

    try:
        import httpx
    except ImportError:
        logger.debug("httpx not installed, skipping httpx interceptor")
        return

    _original_sync_send = httpx.Client.send
    _original_async_send = httpx.AsyncClient.send

    httpx.Client.send = _patched_sync_send  # type: ignore[assignment]
    httpx.AsyncClient.send = _patched_async_send  # type: ignore[assignment]

    _installed = True
    logger.debug("httpx interceptor installed")


def uninstall() -> None:
    """Restaure les méthodes httpx originales."""
    global _original_sync_send, _original_async_send, _installed

    if not _installed:
        return

    try:
        import httpx
    except ImportError:
        return

    if _original_sync_send is not None:
        httpx.Client.send = _original_sync_send  # type: ignore[assignment]
    if _original_async_send is not None:
        httpx.AsyncClient.send = _original_async_send  # type: ignore[assignment]

    _original_sync_send = None
    _original_async_send = None
    _installed = False
    logger.debug("httpx interceptor uninstalled")


def is_installed() -> bool:
    return _installed
