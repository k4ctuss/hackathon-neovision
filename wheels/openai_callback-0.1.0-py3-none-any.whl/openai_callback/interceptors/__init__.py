"""Installation et désinstallation des intercepteurs HTTP.

Expose ``install()`` / ``uninstall()`` qui activent les monkeypatches
sur httpx et requests (si présents). L'installation est idempotente.
"""

from __future__ import annotations

from openai_callback.interceptors import _httpx, _requests


def install() -> None:
    """Installe tous les intercepteurs disponibles (httpx + requests). Idempotent."""
    _httpx.install()
    _requests.install()


def uninstall() -> None:
    """Restaure toutes les méthodes originales."""
    _httpx.uninstall()
    _requests.uninstall()


def is_installed() -> bool:
    """Retourne ``True`` si au moins un intercepteur est installé."""
    return _httpx.is_installed() or _requests.is_installed()
